/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


/**
 *
 * @author ASUS
 */
public class koneksi {
      public static Connection cn;
      public static Statement st;
      
      
      public static Connection koneksi(){
          try {
               DriverManager.registerDriver(new com.mysql.jdbc.Driver());
              cn = DriverManager.getConnection("jdbc:mysql://localhost/db_javacpo", "root", "");
                st = cn.createStatement();
              System.out.println("Berhasil");
          } catch (Exception e) {
              System.out.println("Gagal");
          }
          return cn;
      }
      
}
