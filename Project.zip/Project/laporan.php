<?php
	$con = mysqli_connect("localhost","root","","db_javacpo");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, intial-scale=1">
	<title>Cetak Laporan </title>
<body onload="window.print()" style="font-family:'Trebuchet MS', 'Lucida Grande', 'Lucida Sans Unicode', 'Lucida Sans', Tahoma,  sans-serif;background-color: #eee">
	<div class="container" align="center" style="width: 60%;margin-left: 20%;border: solid 1px black;background-color: #fff;box-shadow: 1px 1px 1px black">	
		<table align="center">
			<tr>
				<td>
			 		<h1 style="margin:0">Hasil Voting</h1>
			 		<h4 style="margin:0;margin-top:4px;"></h4>
			 	</td>
			 </tr>
		</table>
		<hr>
		<h3 align="center">Daftar Calon Pengurus Osis</h3>
		<p align="center">Periode 2018/2019</p>
		<table width="100%" border="0" cellpadding="2" cellspacing="0" style="border:1px solid black;" align="center">
			<thead>
				<tr>
					<th width="5%"  style="border:1px solid black">No.</th>
					<th width="12%" style="border:1px solid black">Nis</th>
					<th  style="border:1px solid black">Nama</th>
					<th  style="border:1px solid black">Hasil Voting</th>
				</tr>
			</thead>
			<tbody>
				<?php
		
		
					$sql = "SELECT * FROM tb_cpo order by voting DESC";
					$query = mysqli_query($con, $sql);
				$no = 0;
					while ($data = mysqli_fetch_array($query)) {
						$no++;

		        ?>	
					<tr>
						<td align="center" style="border:1px solid black"><?php echo $no; ?>.</td>
	<td align="center" style="border:1px solid black"><?php echo $data['nis']; ?></td>
	<td align="center" style="border:1px solid black"><?php echo ucwords($data['nama']); ?></td>
	<td align="center" style="border:1px solid black"><?php echo ucwords($data['voting']); ?></td>
					</tr>
				<?php } ?>
			</tbody>
		</table>
		</div>
</body>
</html>